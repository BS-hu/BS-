

#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>





extern int age;

//�ؼ���static
static int suiji_3 = 9;

static int add_1(int shu_1, int shu_2)
{
	return shu_1 + shu_2;
}