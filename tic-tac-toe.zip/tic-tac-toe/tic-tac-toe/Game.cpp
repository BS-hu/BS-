

#define _CRT_SECURE_NO_WARNINGS 1


#include <stdio.h>





int main()
{

	const int size = 3;
	int board[size][size];
	int x, y;
	int numofX, numofO;
	int result = -1;

	//�������
	printf("����1/0");
	for (x = 0; x < size; x++)
	{
		for (y = 0; y < size; y++)
		{
			scanf("%d", &board[x][y]);
		}

	}

	//�����
	for (x = 0; x < size && result == -1; x++)
	{
		numofO = 0; numofX = 0;
		for (y = 0; y < size; y++)
		{
			if (board[x][y] == 0)
			{
				numofO++;
			}
			else
			{
				numofX++;
			}


		}

		if (numofO == size)
		{
			result = 0;
		}

		else if (numofX == size)
		{
			result == 1;

		}

	}

	//���Խ���
	numofO = 0; numofX = 0;
	for (x = 0; x < size; x++)
	{
		
		
			if (board[x][x] == 0)
			{
				numofO++;
			}
			else
			{
				numofX++;
			}


		

		if (numofO == size)
		{
			result = 0;
		}

		else if (numofX == size)
		{
			result == 1;

		}

	}

	numofO = 0; numofX = 0;
	for (y = 0; y < size; y++)
	{


		if (board[y][size - y - 1] == 0)
		{
			numofO++;
		}
		else
		{
			numofX++;
		}




		if (numofO == size)
		{
			result = 0;
		}

		else if (numofX == size)
		{
			result == 1;

		}

	}



	//�ж�ʤ��
	if (result == 0)
	{
		printf("OӮ");

	}

	else if (result == 1)
	{
		printf("XӮ");

	}

	else
	{
		printf("ƽ��");

	}





	return 0;
}













